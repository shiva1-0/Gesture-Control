import serial, pyautogui, time
ser = serial.Serial('COM4', 9600)

change = False
while True:
    incoming_data = ser.readline().decode().strip()
    print(incoming_data)

    if 'Play/Pause' in incoming_data:
        pyautogui.press('space')

    if 'new' in incoming_data:
        pyautogui.hotkey('ctrl', 't')
    
    if 'close' in incoming_data:
        pyautogui.hotkey('ctrl', 'w')
    
    if 'up' in incoming_data:
        pyautogui.press('up')

    if 'down' in incoming_data:
        pyautogui.press('down')

    if 'right' in incoming_data:
        pyautogui.press('right')

    if 'left' in incoming_data:
        pyautogui.press('left')

    if 'change' in incoming_data:
        if change==False:
            pyautogui.keyDown('alt') 
            pyautogui.press('tab')
            change = True
        else:
            pyautogui.press('tab')

    if change == True and 'nothing' in incoming_data:
        pyautogui.keyUp('alt') 
        change = False

    if 'switch' in incoming_data:
        pyautogui.hotkey('ctrl', 'tab')
    
    time.sleep(0.2)